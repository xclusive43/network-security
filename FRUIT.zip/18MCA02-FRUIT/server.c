// Server.c
#include <stdlib.h> // for basic memmory allocation and deallocation
#include <stdio.h> // for file read and write
#include <netdb.h> 
#include <unistd.h>
#include<math.h>
#include <netinet/in.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 

#define MAX 100
#define PORT 8080 
#define SA struct sockaddr 

int q[10];

 
void doCalculation(int sockfd) 

{   
    
    q[0]=20;
    q[1]=20;
    q[2]=20;
    q[3]=20;
    q[4]=20;
    

    //char *fname ="5.Carambola\t2.bael\t3.Blueberry\t4.Mango\t5.Apple";
    char buff1[MAX],buff[MAX];     
               
    int a ,ch;
     
    
     int i=0;
     
    for( ;; )
     
    {   
        printf("*Fruit STORE-DataBase*\n");
        printf("Id   Name   Quantity\n");
        printf("*********************\n");
        printf("A   Carambola   %d\nB   Bael        %d\nC   Blueberry   %d\nD   Mango       %d\nE   Apple       %d\n",q[0],q[1],q[2],q[3],q[4]);
        printf("*********************\n");
        a =0 ;

    if ( read(sockfd, buff, sizeof(buff) ) == 0 ){
        
            printf(" --- Failed To Read \n --- Maybe Socket Is Closed .. \n --  Exiting \n ");
            return;
        
        }
        
        
        

     printf("%s\n",buff);//connected..to clent msg
     bzero(buff, MAX);     
     write(sockfd,"Name-> Carambola  Bael  Blueberry  Mango  Apple  \n",sizeof("Name-> Carambola  Bael  Blueberry  Mango  Apple  \n"));
     bzero(buff, MAX);

    read(sockfd, buff, sizeof(buff));
    if (strncmp("exit", buff, 4) == 0) { 
            printf("Server Exit...\n"); 
            write(sockfd,"exit",sizeof("exit"));
            break;

        } 
         sscanf(buff,"%c%d" , &ch,&a);
    printf("*********************\n");
    printf("\n\n Order Requested is %c\t%d\n",ch,a);
      
        switch( ch ){
        
            case 'A' : if(q[0]<=0)
                      {
                          write(sockfd,"Carambola Out of Stock\n",sizeof("Carambola Out of Stock\n"));
                      }
                      else if(a>q[0])
                      {
                          write(sockfd,"Quantity is more than stock\n",sizeof("Quantity is more than stock\n"));
                      }
                      else{
                            q[0] -=a;
                            write(sockfd," Carambola Order successfull\n",sizeof("Carambola Order successfull\n"));
                          }
               
                        break ;
            case 'B' : if(q[1]<=0)
                      {
                          write(sockfd,"Bael Out of Stock\n",sizeof("Beal Out of Stock\n"));
                      }
                      else if( a>q[1] )
                      {
                          write(sockfd,"Quantity is more than stock\n",sizeof("Quantity is more than stock\n"));
                      }
                      else{
                            q[1] -=a;
                            write(sockfd,"Beal Order successfull\n",sizeof("Bael Order successfull\n"));
                          }
               
                        break ;
            case 'C' : if(q[2]<=0)
                      {
                          write(sockfd,"Blueberry Out of Stock\n",sizeof("Blueberry Out of Stock\n"));
                      }
                      else if(a>q[2] ) 
                      {
                          write(sockfd,"Quantity is more than stock\n",sizeof("Quantity is more than stock\n"));
                      }
                      else{
                            q[2] -=a;
                            write(sockfd,"Blueberry Order successfull\n",sizeof("Blueberry Order successfull\n"));
                          }
                        break ;
            case 'D' : if(q[3]<=0)
                      {
                          write(sockfd,"Mango Out of Stock\n",sizeof("Mango Out of Stock\n"));
                      }
                      else if(a>q[3])
                      {
                          write(sockfd,"Quantity is more than stock\n",sizeof("Quantity is more than stock\n"));
                      }
                      else{
                            q[3] -=a;
                            write(sockfd,"Mango Order successfull\n",sizeof("Mango Order successfull\n"));
                          }
                        break ;
            case 'E' : if(q[4]<=0)
                      {
                          write(sockfd,"Apple Out of Stock\n",sizeof("Apple Out of Stock\n"));
                      }
                      else if(a>q[4] )
                      {
                          write(sockfd,"Quantity is more than stock\n",sizeof("Quantity is more than stock\n"));
                      }
                      else{
                            q[4] -=a;
                            write(sockfd,"Apple Order successfull\n",sizeof("Apple Order successfull\n"));
                          }
                        break ;
             
            default : write( sockfd , "Invalid ID Or Quantity.\n" , sizeof("Invalid ID Or Quantity.\n") );
            
        }
 
    } 
    
} 


int main() 
{ 
    int sockfd, connfd, len;                 // create socket file descriptor 
    struct sockaddr_in servaddr, cli;         // create structure object of sockaddr_in for client and server

    // socket create and verification 
    sockfd = socket(AF_INET, SOCK_STREAM, 0);             // creating a TCP socket ( SOCK_STREAM )
    
    if (sockfd == -1) { 
        printf("socket creation failed...\n"); 
        exit(0); 
    } 
    else
        printf("Socket successfully created..\n"); 
    
    // empty the 
    bzero(&servaddr, sizeof(servaddr)); 

    // assign IP, PORT 
    servaddr.sin_family = AF_INET;                    // specifies address family with IPv4 Protocol 
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);     // binds to any address
    servaddr.sin_port = htons(PORT);                 // binds to PORT specified

    // Binding newly created socket to given IP and verification 
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
        printf("socket bind failed...\n"); 
        exit(0); 
    } 
    else
        printf("Socket successfully binded..\n"); 

    // Now server is ready to listen and verification 
    if ((listen(sockfd, 5)) != 0) { 
        printf("Listen failed...\n"); 
        exit(0); 
    } 
    else
    printf("Server listening..\n"); 
    
    len = sizeof(cli); 

    // Accept the data packet from client and verification 
    connfd = accept(sockfd, (SA*)&cli, &len);     // accepts connection from socket
    
    if (connfd < 0) { 
        printf("server acccept failed...\n"); 
        exit(0); 
    } 
    else
        printf("server acccept the client...\n"); 

    // Function for recieving Expression and 
    doCalculation(connfd); 

    // After transfer close the socket 
    close(sockfd); 
    return 0;
}
