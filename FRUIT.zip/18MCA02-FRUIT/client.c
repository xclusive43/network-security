 // for fruit management system
#include <netdb.h> 
#include <unistd.h>
#include <netinet/in.h>
#include <stdio.h>         
#include <stdlib.h> 
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h> 
#include <sys/socket.h> 

#define MAX 100
#define PORT 8080 
#define SA struct sockaddr 
int q1[5];
void sendCalculation(int sockfd) 
{    q1[0]=20;q1[1]=20;q1[2]=20;q1[3]=20;q1[4]=20;
    char buff[MAX]; 
    char buff1[MAX];
    int a1;
    char ch1;     
    bzero(buff,MAX);
        
    
    for( ;; )
    {    
         a1=0;
         bzero(buff1,MAX);
         write(sockfd ,"Connected...to Client", sizeof("Connected...to Client"));        // write to the stream 
        
           
        bzero(buff,MAX);

        printf("****Fruit STORE******\n");
        printf("ID  ->   A         B         C       D     E\n");

        read(sockfd,buff,sizeof(buff));
        printf("%s",buff);
        bzero(buff,MAX);
        printf("Quantity->%d       %d        %d      %d    %d\n",q1[0],q1[1],q1[2],q1[3],q1[4]);
        printf("*********************\n");
       

        printf("Enter the fruit-id  and Quantity to buy(examle B20 for ID+quantity):");
        scanf("%s",buff1);
        sscanf(buff1,"%c%d",&ch1,&a1);
        //printf("%c -> %d\n",ch1,a1);
        switch(ch1)
        {
            case 'A':if(a1>q1[0]){printf("\n");}
                     else{
                         q1[0]-=a1;

                     }
                     break;
            case 'B':if(a1>q1[1]){printf("\n");}
                     else{
                         q1[1]-=a1;

                     }
                     break;
            case 'C':if(a1>q1[2]){printf("\n");}
                     else{
                         q1[2]-=a1;

                     }
                     break;
            case 'D':if(a1>q1[3]){printf("\n");}
                     else{
                         q1[3]-=a1;

                     }
                     break;
            case 'E':if(a1>q1[4]){printf("\n");}
                     else{
                         q1[4]-=a1;

                     }
                     break;       
        }

        write(sockfd , buff1 , sizeof(buff1)); 
        bzero(buff1,MAX);

        read(sockfd,buff,sizeof(buff));
         if(strncmp("exit",buff,4) == 0 ){
        
            printf("Exiting ...\n");
            return ;
            
        } 
        printf("************************\n");
        printf("\nOperation Result : %s",buff); 
        printf("************************\n");       
    }
} 

int main() 
{ 
    int sockfd, connfd; 
    struct sockaddr_in servaddr, cli; 

    // socket create and varification 
    sockfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        printf("socket creation failed...\n"); 
        exit(0); 
    } 
    else
        printf("Socket successfully created..\n"); 
    
    bzero(&servaddr, sizeof(servaddr)); 

    // assign IP, PORT 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
    servaddr.sin_port = htons(PORT); 

    // connect the client socket to server socket 
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
        printf("connection with the server failed...\n"); 
        exit(0); 
    } 
    else
        printf("connected to the server..\n"); 

    // function for sending Expression 
    sendCalculation(sockfd); 

    // close the socket 
    close(sockfd); 
}
