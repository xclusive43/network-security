//udp server code for chating with client
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
 #define SA struct sockaddr

#define PORT  8080 
#define MAXLINE 1024 
#define max 80
  int main() { 
    int sockfd; 
    char buffer[MAXLINE]; 
    //char *hello ; 
    struct sockaddr_in servaddr, cliaddr; 
      
    // Creating socket file descriptor 
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
        perror("socket creation failed"); 
        exit(EXIT_FAILURE); 
    } 
      bzero(&servaddr,sizeof(servaddr));
      bzero(&cliaddr,sizeof(cliaddr));
    // Filling server information 
    servaddr.sin_family    = AF_INET; // IPv4 
    servaddr.sin_addr.s_addr = INADDR_ANY; 
    servaddr.sin_port = htons(PORT); 
      
    // Bind the socket with the server address 
    if ( bind(sockfd, (SA*)&servaddr, sizeof(servaddr)) < 0 ) 
    { 
        perror("bind failed"); 
        exit(EXIT_FAILURE); 
    } 
      else
      {
        printf("server is active..............\n");
      }
    int len, n; 
  printf(".....SERVER....!\n");
  for(;;){
     
     len = sizeof(cliaddr);  //len is value/resuslt 
     recvfrom(sockfd, (char *)buffer, MAXLINE,MSG_WAITALL, ( struct sockaddr *) &cliaddr,&len); 
    printf("Client : %s", buffer);

      bzero(buffer,MAXLINE); 
      printf("\nenter your message: ");
      n=0;
    while((buffer[n++]=getchar())!='\n')
    ;
   sendto(sockfd, (char *)buffer, MAXLINE, MSG_WAITALL, ( struct sockaddr *) &cliaddr,sizeof(cliaddr));

   if((strncmp("exit",buffer,4))==0)
      {
       printf("server exiting.....!\n");
       break;
       }
       bzero(buffer,MAXLINE);    
    }
      return 0; 
} 



