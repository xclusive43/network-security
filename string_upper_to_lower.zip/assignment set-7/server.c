#include <stdio.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<netdb.h>
#include<stdlib.h>

#define port 8080
#define max 80
#define SA struct sockaddr

int fun(int sockfd)
{
   char buff[max],buff1[max];
   int len,i=0;



   for(;;)
   {

	   bzero(buff,max); bzero(buff1,max);

	   read(sockfd,buff,sizeof(buff));
  
	   printf("\nTHE CLIENT REQUEST : %s",buff);
	   if((strncmp("exit",buff,4))==0)
	   {
		   printf("CLIENT EXITING");
		   write(sockfd,"exit",sizeof("exit"));
		   break;
	   }
         
         len = strlen(buff);
 
	   
	    for(i=0;i<len;i++)
		{
			if(buff[i]>='a' && buff[i]<='z')
			
				buff[i]=buff[i]-32;
                
			
			else if(buff[i]>='A' && buff[i]<='z')
			
				buff[i]=buff[i]+32;
			
		}

		printf("REQUEST SENT OT CLIENT:%s",buff);
        write(sockfd,buff,sizeof(buff));
    
	bzero(buff1,max);

	bzero(buff,max);
	   
   }
}
int main(int argc, char **argv)
{
	 int  sockfd,config,len;
	 struct sockaddr_in servaddr,cli;

	 sockfd=socket(AF_INET,SOCK_STREAM,0);

	 bzero(&servaddr,sizeof(servaddr));

	 servaddr.sin_family=AF_INET;
	 servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	 servaddr.sin_port=htons(port);

	 bind(sockfd,(SA*)&servaddr,sizeof(servaddr));

	 listen(sockfd,5);
	 len=sizeof(cli);
	 config=accept(sockfd,(SA*)&cli,&len);
     

	 fun(config);
	 close(sockfd);
  
}
