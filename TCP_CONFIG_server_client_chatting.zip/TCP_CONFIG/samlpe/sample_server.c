#include <stdio.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<netdb.h>
#include<stdlib.h>

#define port 8080
#define max 80
#define SA struct sockaddr

int fun(int sockfd)
{
   char buff[max];
   int n;

   for(;;)
   {

	   bzero(buff,max);

	   read(sockfd,buff,sizeof(buff));

	   printf(" client: %s",buff);
	   bzero(buff,max);

	   n=0;

	   while((buff[n++]=getchar())!='\n')
	   ;

	   write(sockfd,buff,sizeof(buff));
	   if((strncmp("exit",buff,4))==0)
	   {
		   printf("server exiting");
		   break;
	   }
   }
}
int main(int argc, char **argv)
{
	 int  sockfd,config,len;
	 struct sockaddr_in servaddr,cli;

	 sockfd=socket(AF_INET,SOCK_STREAM,0);

	 bzero(&servaddr,sizeof(servaddr));

	 servaddr.sin_family=AF_INET;
	 servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	 servaddr.sin_port=htons(port);

	 bind(sockfd,(SA*)&servaddr,sizeof(servaddr));

	 listen(sockfd,5);
	 len=sizeof(cli);
	 config=accept(sockfd,(SA*)&cli,&len);
     

	 fun(config);
	 close(sockfd);
  
}
