#include <stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>

#define max 80
#define port 8080
#define SA struct sockaddr
int fun(int sockfd)
{
     char buff[max];
	 int n;

	 for(;;)
	 {
		 bzero(buff,sizeof(buff));
		 printf("enter mss: ");
		 n=0;
		 while((buff[n++]=getchar())!='\n')
		 ;
          write(sockfd,buff,sizeof(buff));

		 bzero(buff,sizeof(buff));

		 read(sockfd,buff,sizeof(buff));
		 printf("server :%s",buff);

		 if((strncmp("exit",buff,4))==0)
		 {
			 printf("exiting");
			 break;

		 }
	 }
}
int main(int argc, char **argv)
{
	 int sockfd,config,len;
	 
	 struct sockaddr_in servaddr,cli;
	sockfd =socket(AF_INET,SOCK_STREAM,0);

  bzero(&servaddr,sizeof(servaddr));
  
  servaddr.sin_family=	AF_INET	;
	servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
  servaddr.sin_port=htons(port);
   connect(sockfd,(SA*)&servaddr,sizeof(servaddr));

   fun(sockfd);
   close(sockfd);
	
	//return 0;
}
